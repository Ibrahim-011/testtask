// script.js

document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('taskInput');
    const addTaskButton = document.getElementById('addTaskButton');
    const taskList = document.getElementById('taskList');

    // Load tasks from local storage
    loadTasks();

    addTaskButton.addEventListener('click', () => {
        if (taskInput.value.trim()) {
            addTask(taskInput.value.trim());
            taskInput.value = '';
        } else {
            alert('Please enter a task!');
        }
    });

    taskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && taskInput.value.trim()) {
            addTask(taskInput.value.trim());
            taskInput.value = '';
        }
    });

    function addTask(task) {
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="task-text">${task}</span>
            <div>
                <button class="edit-button">Edit</button>
                <button class="delete-button">Delete</button>
            </div>
        `;

        const editButton = li.querySelector('.edit-button');
        const deleteButton = li.querySelector('.delete-button');

        editButton.addEventListener('click', () => {
            const newTask = prompt('Edit task:', task);
            if (newTask) {
                li.querySelector('.task-text').textContent = newTask;
                updateLocalStorage();
            }
        });

        deleteButton.addEventListener('click', () => {
            li.remove();
            updateLocalStorage();
        });

        taskList.appendChild(li);
        updateLocalStorage();
    }

    function updateLocalStorage() {
        const tasks = [];
        taskList.querySelectorAll('li').forEach(li => {
            tasks.push(li.querySelector('.task-text').textContent);
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.forEach(task => addTask(task));
    }
});
