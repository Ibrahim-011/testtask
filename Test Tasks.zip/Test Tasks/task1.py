class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def delete(self, data):
        if self.head is None:
            print("List is empty.")
            return
        
        if self.head.data == data:
            self.head = self.head.next
            return
        
        current = self.head
        prev = None
        while current and current.data != data:
            prev = current
            current = current.next
        
        if current is None:
            print(f"Element {data} not found in the list.")
            return
        
        prev.next = current.next

    def search(self, data):
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

    def reverse(self):
        prev = None
        current = self.head
        while current:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev

    def print_list(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

if __name__ == "__main__":
    sll = SinglyLinkedList()
    sll.insert(1)
    sll.insert(2)
    sll.insert(3)
    sll.insert(4)

    print("Original list:")
    sll.print_list()

    print("Reversing the list...")
    sll.reverse()
    sll.print_list()

    print("Searching for 3 in the list:")
    print(sll.search(3))  

    print("Deleting 3 from the list...")
    sll.delete(3)
    sll.print_list()

    print("Searching for 3 in the list:")
    print(sll.search(3)) 
